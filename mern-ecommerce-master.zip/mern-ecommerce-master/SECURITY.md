# Security Policy

## Reporting a Vulnerability

Please submit a pull request to report security bugs.  

I will confirm the problem, audit code to find potential similar problems and coordinate the fix.
